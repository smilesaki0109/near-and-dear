/**
 * Minimal UI strings for Japanese / English.
 * Phase 1: home + browse only. Expand when create/share ships.
 */

export type Locale = "en" | "ja";

export const ui = {
  en: {
    brand: "Near & Dear",
    navHome: "Home",
    heroTitle: "A little warmth for the miles between you",
    heroSubtitle:
      "Browse gentle cards for special days and hard days—made for people living far from home.",
    searchPlaceholder: "Search cards by title…",
    categoryAll: "All",
    categoryEncouragement: "Encouragement",
    categoryBirthday: "Birthday",
    categoryGratitude: "Gratitude",
    categoryMissingHome: "Missing home",
    categoryNewChapter: "New chapter",
    categoryJapan: "Japan 🇯🇵",
    cardsHeading: "Cards for your heart",
    cardsEmpty: "No cards match. Try another word or category.",
    chipHint: "Filter by feeling",
    footerNote: "You are not alone here.",
    navCreateHint: "Tap a card to begin",
    createBack: "Back to browse",
    createHeading: "Add your words",
    createSub:
      "Take your time. When you save, we’ll store your card so you can share a link.",
    createSelectedLabel: "You chose",
    createMessageLabel: "Your message",
    createMessagePlaceholder:
      "Write what feels true, even if it’s simple…",
    createTemplatesHint: "Gentle starters — tap to add",
    createPhotoLabel: "One photo",
    createPhotoButton: "Choose a photo",
    createPhotoReplace: "Replace",
    createPhotoRemove: "Remove photo",
    createPhotoHint: "JPG or PNG, one image.",
    createPreviewLabel: "How your card will feel",
    createPreviewEmpty:
      "Your message will appear here…",
    createSave: "Save card",
    createSaveNote:
      "Creates a shareable link and saves it so you can open it again later.",
    createSavedAck:
      "Saved on this device for preview. We’ll help you share it in the next step.",
    createSaving: "Saving…",
    createShareError: "We couldn’t save that. Please try again.",
    shareKicker: "A card for you",
    shareCopyLink: "Copy link",
    shareCopyShort: "Copy",
    shareCopied: "Copied!",
    shareCopyFailed:
      "Couldn’t copy. You can copy the address from your browser’s bar.",
    shareNative: "Share",
    shareSending: "Sending...",
    shareSent: "Sent with care",
    shareAfterglow: "Your card is on its way.",
    shareUnable: "Unable to share",
    shareLine: "LINE",
    shareTwitter: "X",
    shareInstagram: "Instagram",
    shareInstagramCopied: "Link copied. Paste it in Instagram.",
    shareSocialText: "Someone sent you a card on Near & Dear.",
    shareFooterNote:
      "Whoever sent this picked these words and colors with you in mind.",
    shareBrowseMore: "Browse more cards",
    shareMessageEmpty: "Sometimes words are hard. This space is still a hug.",
    shareNotFoundTitle: "This card isn’t here anymore",
    shareNotFoundBody:
      "This link may be invalid or the card could not be loaded. Ask your friend to send it again, or make a new card.",
  },
  ja: {
    brand: "ニア アンド ディア",
    navHome: "ホーム",
    navCreateHint: "カードを選んで始める",
    heroTitle: "遠くにいても、気持ちがそっと届くように",
    heroSubtitle:
      "特別な日も、つらい日も。故郷から離れて暮らす方へ、やさしいカードを集めました。",
    searchPlaceholder: "タイトルでさがす…",
    categoryAll: "すべて",
    categoryEncouragement: "応援",
    categoryBirthday: "おたんじょうび",
    categoryGratitude: "ありがとう",
    categoryMissingHome: "ふるさと",
    categoryNewChapter: "新しい一歩",
    categoryJapan: "Japan 🇯🇵",
    cardsHeading: "心に寄り添うカード",
    cardsEmpty: "該当するカードがありません。別の言葉やカテゴリを試してください。",
    chipHint: "気持ちで絞り込み",
    footerNote: "ここでは、ひとりじゃありません。",
    createBack: "一覧に戻る",
    createHeading: "ことばを添える",
    createSub:
      "急がなくて大丈夫。保存すると、あとからも開ける共有リンクになります。",
    createSelectedLabel: "えらんだカード",
    createMessageLabel: "メッセージ",
    createMessagePlaceholder:
      "短くても、正直な気持ちで…",
    createTemplatesHint: "やさしい文例 — タップで入ります",
    createPhotoLabel: "写真を1枚",
    createPhotoButton: "写真を選ぶ",
    createPhotoReplace: "差し替える",
    createPhotoRemove: "写真を外す",
    createPhotoHint: "JPG か PNG、1枚まで。",
    createPreviewLabel: "完成イメージ",
    createPreviewEmpty:
      "メッセージがここに表示されます…",
    createSave: "カードを保存",
    createSaveNote:
      "共有用のリンクをつくり、あとからも開けるように保存します。",
    createSavedAck:
      "この端末でのプレビュー用にとっておきました。共有は次のステップで。",
    createSaving: "保存中…",
    createShareError: "保存できませんでした。もう一度お試しください。",
    shareKicker: "あなたへ届くカード",
    shareCopyLink: "リンクをコピー",
    shareCopyShort: "コピー",
    shareCopied: "コピーしました",
    shareCopyFailed:
      "コピーできませんでした。ブラウザのアドレスバーからコピーしてください。",
    shareNative: "共有する",
    shareSending: "送信中...",
    shareSent: "届けました",
    shareAfterglow: "この想いは届いています",
    shareUnable: "共有できません",
    shareLine: "LINE",
    shareTwitter: "X",
    shareInstagram: "Instagram",
    shareInstagramCopied: "リンクをコピーしました。Instagramに貼り付けてください。",
    shareSocialText: "Near & Dearからカードが届きました。",
    shareFooterNote:
      "送ってくれた人が、あなたのことを思いながらえらびました。",
    shareBrowseMore: "ほかのカードを見る",
    shareMessageEmpty:
      "ことばにできない日もあるけれど、そのぶんやさしさが届きます。",
    shareNotFoundTitle: "このカードは見つかりませんでした",
    shareNotFoundBody:
      "リンクが正しくないか、カードを読み込めませんでした。送り直してもらうか、新しいカードをつくってみてください。",
  },
} as const;
